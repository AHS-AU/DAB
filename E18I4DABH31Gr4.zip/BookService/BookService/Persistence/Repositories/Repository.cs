﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BookService.Persistence.Repositories
{
    public class Repository
    {
        // Do rest in 3.2
    }
}